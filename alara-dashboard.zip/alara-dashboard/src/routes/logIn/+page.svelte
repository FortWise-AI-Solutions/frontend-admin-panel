<script>
    import LoginForm from "./LoginForm.svelte";
    
</script>

<div class="login-page">
    <LoginForm />
</div>

<style>
    .login-page {
        max-width: 400px;
        margin: 0 auto;
        padding: 2rem;
    }
</style>
