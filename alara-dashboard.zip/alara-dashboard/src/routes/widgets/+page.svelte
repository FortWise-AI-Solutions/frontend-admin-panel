<script>
</script>

<div class="wid-container">
    <h1>Your Widgets</h1>
    <div class="chat-list">
        <p>Choose across multiple widgets to find the best solution you need</p>
    </div>
</div>

<style>
    .wid-container {
        color: var(--color-fff);
        padding-top: 4.2%;
        padding-left: 5%;
    }

    h1 {
        font-size: 30px;
        font-weight: 500px;
    }

    .chat-list p {
        font-size: 14px;
        color: var(--color-9b9ca3);
        margin-top: 25px;
        font-weight: 500;
    }
</style>
