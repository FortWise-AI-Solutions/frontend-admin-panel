import * as universal from "../../../../src/routes/logIn/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/logIn/+page.svelte";